<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'icon' => 'fa-chart-line',
    'value' => '0',
    'label' => 'Statistik',
    'trend' => null,
    'trendValue' => null,
    'trendIcon' => null,
    'trendClass' => 'stat-trend-up'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'icon' => 'fa-chart-line',
    'value' => '0',
    'label' => 'Statistik',
    'trend' => null,
    'trendValue' => null,
    'trendIcon' => null,
    'trendClass' => 'stat-trend-up'
]); ?>
<?php foreach (array_filter(([
    'icon' => 'fa-chart-line',
    'value' => '0',
    'label' => 'Statistik',
    'trend' => null,
    'trendValue' => null,
    'trendIcon' => null,
    'trendClass' => 'stat-trend-up'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card h-100">
    <div class="card-body p-0">
        <div class="stat-card">
            <div class="stat-content p-4">
                <div class="stat-icon">
                    <i class="fas <?php echo e($icon); ?>"></i>
                </div>
                <div class="stat-value"><?php echo e($value); ?></div>
                <div class="stat-label mb-2"><?php echo e($label); ?></div>
                <?php if($trend): ?>
                <div class="stat-trend <?php echo e($trendClass); ?>">
                    <i class="fas <?php echo e($trendIcon ?? 'fa-arrow-up'); ?> me-1"></i> <?php echo e($trend); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div> <?php /**PATH D:\semester 4\proyek akhir\PA-2-Kel9\Backend Web\resources\views/components/admin/stat-card.blade.php ENDPATH**/ ?>