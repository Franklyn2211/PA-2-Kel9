<?php $__env->startSection('title', 'Data Penduduk - Admin Desa Digital'); ?>

<?php $__env->startSection('page-title', 'Data Penduduk'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="padding-top: 80px;">
    <div class="row">
        <div class="col-12">
            <div class="card animate-on-scroll fadeIn">
                <div class="card-header">
                    <h6 class="mb-0">Data Penduduk</h6>
                    <a href="<?php echo e(route('admin.penduduk.create')); ?>">
                        <button class="btn btn-sm btn-soft-primary">
                            <i class="fas fa-plus me-1"></i> Tambah Data
                        </button>
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive mt-4">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NIK</th>
                                    <th>Nama Lengkap</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Alamat</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Agama</th>
                                    <th>Nomor KK</th>
                                    <th>Aksi</th>
                                </tr>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $residents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($penduduk->nik); ?></td>
                                    <td><?php echo e($penduduk->name); ?></td>
                                    <td><?php echo e($penduduk->gender_label); ?></td>
                                    <td><?php echo e($penduduk->address); ?></td>
                                    <td><?php echo e($penduduk->birth_date); ?></td>
                                    <td><?php echo e($penduduk->religion); ?></td>
                                    <td><?php echo e($penduduk->family_card_number); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.penduduk.edit', $penduduk->id)); ?>" class="btn btn-sm btn-soft-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.penduduk.destroy', $penduduk->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-soft-danger" onclick="return confirm('Yakin ingin menghapus?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($residents->isEmpty()): ?>
                                <tr>
                                    <td colspan="9" class="text-center">Data Penduduk Kosong</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 4\proyek akhir\PA-2-Kel9\Backend Web\resources\views/admin/penduduk/index.blade.php ENDPATH**/ ?>