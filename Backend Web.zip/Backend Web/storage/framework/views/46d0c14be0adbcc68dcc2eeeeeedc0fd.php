<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => 'Selamat Datang',
    'subtitle' => 'Subtitle',
    'buttons' => []
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => 'Selamat Datang',
    'subtitle' => 'Subtitle',
    'buttons' => []
]); ?>
<?php foreach (array_filter(([
    'title' => 'Selamat Datang',
    'subtitle' => 'Subtitle',
    'buttons' => []
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="welcome-card animate-on-scroll fadeIn">
    <div class="welcome-content">
        <div class="welcome-title"><?php echo e($title); ?></div>
        <div class="welcome-subtitle"><?php echo e($subtitle); ?></div>
        <div class="welcome-actions">
            <?php echo e($slot); ?>

        </div>
    </div>
</div> <?php /**PATH D:\semester 4\proyek akhir\PA-2-Kel9\Backend Web\resources\views/components/admin/welcome-card.blade.php ENDPATH**/ ?>