<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => 'Dokumen',
    'user' => 'Pengguna',
    'date' => 'Tanggal',
    'status' => 'pending',
    'statusText' => 'Dalam Proses',
    'icon' => 'fa-file-alt'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => 'Dokumen',
    'user' => 'Pengguna',
    'date' => 'Tanggal',
    'status' => 'pending',
    'statusText' => 'Dalam Proses',
    'icon' => 'fa-file-alt'
]); ?>
<?php foreach (array_filter(([
    'title' => 'Dokumen',
    'user' => 'Pengguna',
    'date' => 'Tanggal',
    'status' => 'pending',
    'statusText' => 'Dalam Proses',
    'icon' => 'fa-file-alt'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="document-card <?php echo e($status); ?>">
    <div class="document-icon bg-<?php echo e($status === 'completed' ? 'success' : 'warning'); ?>-soft text-<?php echo e($status === 'completed' ? 'success' : 'warning'); ?>">
        <i class="fas <?php echo e($icon); ?>"></i>
    </div>
    <div class="document-info">
        <div class="document-title"><?php echo e($title); ?></div>
        <div class="document-meta">
            <div><i class="fas fa-user"></i> <?php echo e($user); ?></div>
            <div><i class="fas fa-calendar"></i> <?php echo e($date); ?></div>
        </div>
    </div>
    <div class="document-status bg-<?php echo e($status === 'completed' ? 'success' : 'warning'); ?>-soft text-<?php echo e($status === 'completed' ? 'success' : 'warning'); ?>">
        <?php echo e($statusText); ?>

    </div>
</div> <?php /**PATH D:\semester 4\proyek akhir\PA-2-Kel9\Backend Web\resources\views/components/admin/document-card.blade.php ENDPATH**/ ?>